package com.example.bt;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BT = 0;
    private static final int REQUEST_DISCOVER_BT = 1;

    TextView mStatusBlueTv, mPairedTv;
    Button onBt, offBt, pairBt;
    ListView btListView;

    BluetoothAdapter mBluetoothAdapter;
    Set<BluetoothDevice> pairedDevices;

    public static String EXTRA_ADDRESS = "device_address";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mStatusBlueTv = findViewById(R.id.statusBluetoothTv);
        mPairedTv     = findViewById(R.id.pairedTv);
        onBt        = findViewById(R.id.onBt);
        offBt      = findViewById(R.id.offBt);
        pairBt    = findViewById(R.id.pairBt);
        btListView = findViewById(R.id.btListView);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null){
            mStatusBlueTv.setText("블루투스 연결 불가능");
        }
        else {
            mStatusBlueTv.setText("블루투스 연결 가능");
        }


        onBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!mBluetoothAdapter.isEnabled()) {
                    showToast("권한 요청을 수락 해주세요.");
                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(intent, REQUEST_ENABLE_BT);
                }
                else{
                    showToast("이미 블루투스가 켜져있습니다. .");
                }
            }
        });

        offBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBluetoothAdapter.isEnabled()) {
                    mBluetoothAdapter.disable();
                    showToast("블루투스 꺼짐");
                } else {
                    showToast("이미 블루투스가 꺼져있습니다.");
                }
            }
        });

        pairBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pairedDeviceList();
            }
        });

    }
    private void pairedDeviceList() {
        pairedDevices = mBluetoothAdapter.getBondedDevices();
        ArrayList list = new ArrayList();

        if (pairedDevices.size() > 0) {

            for (BluetoothDevice device : pairedDevices) {
                list.add(device.getName().toString() + "\n" + device.getAddress().toString());
            }

        } else {
            Toast.makeText(getApplicationContext(), "디바이스를 찾을 수 없습니다. 블루투스를 켜주세요.", Toast.LENGTH_SHORT).show();
        }
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
        btListView.setAdapter(adapter);
        btListView.setOnItemClickListener(mListClickListener);
    }
    private AdapterView.OnItemClickListener mListClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String info = ((TextView) view).getText().toString();
            String address = info.substring(info.length()-17);

            Intent intent = new Intent(MainActivity.this, ControlActivity.class);
            intent.putExtra(EXTRA_ADDRESS, address);
            startActivity(intent);
        }
    };



        private void showToast(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

}