package com.example.bt;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.UUID;

public class ControlActivity extends AppCompatActivity {
    TextView mtvRe;
    Button mOnBtn, mOffBtn,cw,ccw,mb8h,mb12h,mb24h;
    String address;
    private ProgressDialog progressDialog;
    BluetoothAdapter mBluetoothAdapter;
    BluetoothSocket mBluetoothSocket;
    private boolean isBTConnected = false;
    static final UUID mUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        address = intent.getStringExtra(MainActivity.EXTRA_ADDRESS);

        setContentView(R.layout.activity_ctrl);

        mtvRe = (TextView) findViewById(R.id.tvRe);

        mOnBtn = (Button) findViewById(R.id.onBtn);
        mOffBtn = (Button) findViewById(R.id.offBtn);
        cw=(Button)findViewById(R.id.cw);
        ccw=(Button)findViewById(R.id.ccw);

        mb8h = (Button) findViewById(R.id.b8h);
        mb12h = (Button) findViewById(R.id.b12h);
        mb24h = (Button) findViewById(R.id.b24h);

        new ConnectBT().execute();

        mOnBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast("시리얼 모니터 확인");
                sendString("0");
            }
        });
        mOffBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Disconnect();
            }
        });

        cw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendString("1");
            }
        });
        ccw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendString("2");
            }
        });

        mb8h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast("8시간마다 반복");
                sendString("3");
            }
        });
        mb12h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast("12시간마다 반복");
                sendString("4");
            }
        });
        mb24h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast("24시간마다 반복");
                sendString("5");
            }
        });

    }


    private void sendString(String value) {
        if ( mBluetoothSocket != null ) {
            try {

                mBluetoothSocket.getOutputStream().write(value.toString().getBytes());
            } catch ( IOException e ) {
                toast("Error");
            }
        }
    }

    private void Disconnect() {
        if ( mBluetoothSocket != null ) {
            try {
                mBluetoothSocket.close();
            } catch ( IOException e ) {
                toast("Error");
            }
        }
        finish();
    }

    private void toast(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
    }

    private class ConnectBT extends AsyncTask<Void, Void, Void> {
        private boolean ConnectSuccess = true;

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(ControlActivity.this, "연결중...", "조금만 기다려주세요.");
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                if ( mBluetoothSocket == null || !isBTConnected ) {
                    mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                    BluetoothDevice dispositivo = mBluetoothAdapter.getRemoteDevice(address);
                    mBluetoothSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(mUUID);
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    mBluetoothSocket.connect();
                }
            } catch (IOException e) {
                ConnectSuccess = false;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if ( !ConnectSuccess ) {
                toast("연결 실패");
                finish();
            } else {
                toast("연결 성공");
                isBTConnected = true;
            }
            progressDialog.dismiss();
        }
    }
}
